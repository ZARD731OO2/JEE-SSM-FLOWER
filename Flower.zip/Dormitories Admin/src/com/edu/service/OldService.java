package com.edu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.edu.common.utils.Page;
import com.edu.po.Old;
import com.edu.po.User;


public interface OldService {

	public Page<Old> findOldByCond2(Integer page, Integer rows, Old old);
	public Integer  addOld(Old old);
	public Integer addOld(List<Old> olds);
	public Integer findOldModify(Old old);
	public Integer deleteOld(@Param("oldname") String oldname);
	public Old findOldByOldname(String oldname);

}
