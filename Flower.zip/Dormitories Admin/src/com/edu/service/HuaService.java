package com.edu.service;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.edu.common.utils.Page;
import com.edu.po.Pro;
import com.edu.po.Hua;
public interface HuaService {
	public Page<Hua> findHuaByCond2(Integer page, Integer rows, Hua hua);
	public Integer  addHua(Hua hua);
	public Integer addHua(List<Hua> huas);
	public Integer deleteHua(@Param("name") String name);
	public Hua findHuaByName(String name);
	public Integer findHuaModify(Hua hua);
}
