package com.edu.service.impl;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edu.common.utils.Page;
import com.edu.dao.HuaDao;
import com.edu.po.Pro;
import com.edu.po.Hua;
import com.edu.po.User;
import com.edu.service.HuaService;
@Service
public class HuaServiceImpl implements HuaService{
	@Autowired
	private HuaDao huaDao;
	@Override
	public Page<Hua> findHuaByCond2(Integer page,Integer rows,Hua hua) {
		// TODO Auto-generated method stub
		
		RowBounds rowBounds = new RowBounds((page-1) * rows, rows);
//		// 查询客户列表
		List<Hua> huas=huaDao.findHuaByCond2(rowBounds,hua);
	//	
	//
//		// 查询课程列表总记录数
		Integer count =huaDao.findHuaCountByCond2(hua);
//		// 创建Page返回对象
		Page<Hua> result = new Page<Hua>();
		result.setPage(page);
		result.setRows(huas);
		result.setSize(rows);
		result.setTotal(count);
		return result;
	}
	
	
	@Override
	public Integer addHua(Hua hua) {
		// TODO Auto-generated method stub
		return huaDao.addHua(hua);
	}

	@Override
	public Integer addHua(List<Hua> huas) {
		// TODO Auto-generated method stub
		int count=0;
		for(Hua hua :huas){
			System.out.println(hua);
			count+=huaDao.addHua(hua);
			
		}
		return count;
	}
	
	
	@Override
	public Integer deleteHua(String name) {
		// TODO Auto-generated method stub
		return huaDao.deleteHua(name);
	}
	
	
	//根据名称查询
	public Hua findHuaByName(String name){
		return huaDao.findHuaByName(name);
	}
	
	//编辑供应商女
	@Override
	public Integer findHuaModify(Hua hua) {
		// TODO Auto-generated method stub
		
		return huaDao.findHuaModify(hua);
	}
	
	
	
	
}
