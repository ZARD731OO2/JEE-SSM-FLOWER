package com.edu.service.impl;

import java.util.List;

import org.apache.ibatis.session.RowBounds;

import com.edu.common.utils.Page;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.common.utils.Page;
//import com.edu.dao.StudentDao;
import com.edu.dao.ProDao;
import com.edu.dao.UserDao;
//import com.edu.po.Student;
import com.edu.po.Pro;
import com.edu.po.User;
//import com.edu.service.StudentService;
import com.edu.service.ProService;

@Service
public class ProServiceImpl implements ProService{
	@Autowired
	private ProDao proDao;
	@Override
	public Page<Pro> findProByCond2(Integer page,Integer rows,Pro pro) {
		// TODO Auto-generated method stub
		
		RowBounds rowBounds = new RowBounds((page-1) * rows, rows);
//		// 查询客户列表
		List<Pro> pros=proDao.findProByCond2(rowBounds,pro);
	//	
	//
//		// 查询课程列表总记录数
		Integer count =proDao.findProCountByCond2(pro);
//		// 创建Page返回对象
		Page<Pro> result = new Page<Pro>();
		result.setPage(page);
		result.setRows(pros);
		result.setSize(rows);
		result.setTotal(count);
		return result;
	}
	
	
	@Override
	public Integer addPro(Pro pro) {
		// TODO Auto-generated method stub
		return proDao.addPro(pro);
	}

	@Override
	public Integer addPro(List<Pro> pros) {
		// TODO Auto-generated method stub
		int count=0;
		for(Pro pro :pros){
			System.out.println(pro);
			count+=proDao.addPro(pro);
			
		}
		return count;
	}
	
	//删除供应商信息
	@Override
	public Integer deletePro(String proname) {
		// TODO Auto-generated method stub
		return proDao.deletePro(proname);
	}

	//根据供应商姓名查询
	public Pro findProByProname(String proname){
		return proDao.findProByProname(proname);
	}
	
	
	//编辑供应商信息
	@Override
	public Integer findProModify(Pro pro) {
		// TODO Auto-generated method stub
		
		return proDao.findProModify(pro);
	}
}
