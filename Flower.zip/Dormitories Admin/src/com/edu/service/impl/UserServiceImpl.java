package com.edu.service.impl;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.common.utils.Page;
//import com.edu.dao.StudentDao;
import com.edu.dao.UserDao;

//import com.edu.po.Student;
import com.edu.po.User;
//import com.edu.service.StudentService;
import com.edu.service.UserService;
@Service
public class UserServiceImpl implements UserService{
@Autowired
	private UserDao userDao;

@Override
public User findUserByIdAndPas(User user) {
	// TODO Auto-generated method stub
	return userDao.findUserByIdAndPas(user);
}

@Override
public User register(User user) {
	return userDao.register(user);
	
}

@Override
public Page<User> findUserByCond2(Integer page,Integer rows,User user) {
	// TODO Auto-generated method stub
	
	RowBounds rowBounds = new RowBounds((page-1) * rows, rows);
//	// 查询客户列表
	List<User> users=userDao.findUserByCond2(rowBounds,user);
//	
//
//	// 查询课程列表总记录数
	Integer count =userDao.findUserCountByCond2(user);
//	// 创建Page返回对象
	Page<User> result = new Page<User>();
	result.setPage(page);
	result.setRows(users);
	result.setSize(rows);
	result.setTotal(count);
	return result;
}

@Override
public Integer findUserModify(User user) {
	// TODO Auto-generated method stub
	
	return userDao.findUserModify(user);
}
//根据ID查询用户
public User findUserById(int id){
	return userDao.findUserById(id);
}
//删除用户
@Override
public Integer deleteUser(Integer id) {
	// TODO Auto-generated method stub
	return userDao.deleteUser(id);
}


@Override
public List<User> findUserByIds(Integer[] ids) {
	// TODO Auto-generated method stub
	List<User>users=new ArrayList<User>();
	for(Integer id:ids){
		
		users.add(userDao.findUserById(id));
	}
	
	return users;
}

@Override
public Integer addUser(User user) {
	// TODO Auto-generated method stub
	return userDao.addUser(user);
}

@Override
public int addUser(List<User> users) {
	// TODO Auto-generated method stub
	int count=0;
	for(User user :users){
		System.out.println(user);
		count+=userDao.addUser(user);
		
	}
	return count;
}
}
