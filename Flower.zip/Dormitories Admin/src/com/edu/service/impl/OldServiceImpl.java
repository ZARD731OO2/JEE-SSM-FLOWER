package com.edu.service.impl;

import java.util.List;

import org.apache.ibatis.session.RowBounds;

import com.edu.common.utils.Page;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.common.utils.Page;
//import com.edu.dao.StudentDao;
import com.edu.dao.OldDao;
import com.edu.dao.UserDao;
//import com.edu.po.Student;
import com.edu.po.Old;
import com.edu.po.User;
//import com.edu.service.StudentService;
import com.edu.service.OldService;

@Service
public class OldServiceImpl implements OldService{
	@Autowired
	private OldDao oldDao;
	@Override
	public Page<Old> findOldByCond2(Integer page,Integer rows,Old old) {
		// TODO Auto-generated method stub
		
		RowBounds rowBounds = new RowBounds((page-1) * rows, rows);
//		// 查询客户列表
		List<Old> olds=oldDao.findOldByCond2(rowBounds,old);
	//	
	//
//		// 查询课程列表总记录数
		Integer count =oldDao.findOldCountByCond2(old);
//		// 创建Page返回对象
		Page<Old> result = new Page<Old>();
		result.setPage(page);
		result.setRows(olds);
		result.setSize(rows);
		result.setTotal(count);
		return result;
	}
	
	
	@Override
	public Integer addOld(Old old) {
		// TODO Auto-generated method stub
		return oldDao.addOld(old);
	}

	@Override
	public Integer addOld(List<Old> olds) {
		// TODO Auto-generated method stub
		int count=0;
		for(Old old :olds){
			System.out.println(old);
			count+=oldDao.addOld(old);
			
		}
		return count;
	}
	
	//删除空巢老人信息
	@Override
	public Integer deleteOld(String oldname) {
		// TODO Auto-generated method stub
		return oldDao.deleteOld(oldname);
	}

	//根据空巢老人姓名查询老人
	public Old findOldByOldname(String oldname){
		return oldDao.findOldByOldname(oldname);
	}
	
	
	//编辑空巢老人信息
	@Override
	public Integer findOldModify(Old old) {
		// TODO Auto-generated method stub
		
		return oldDao.findOldModify(old);
	}
}
