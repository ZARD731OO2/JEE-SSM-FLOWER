package com.edu.service.impl;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edu.common.utils.Page;
import com.edu.dao.SonDao;
import com.edu.po.Old;
import com.edu.po.Son;
import com.edu.po.User;
import com.edu.service.SonService;
@Service
public class SonServiceImpl implements SonService{
	@Autowired
	private SonDao sonDao;
	@Override
	public Page<Son> findSonByCond2(Integer page,Integer rows,Son son) {
		// TODO Auto-generated method stub
		
		RowBounds rowBounds = new RowBounds((page-1) * rows, rows);
//		// 查询客户列表
		List<Son> sons=sonDao.findSonByCond2(rowBounds,son);
	//	
	//
//		// 查询课程列表总记录数
		Integer count =sonDao.findSonCountByCond2(son);
//		// 创建Page返回对象
		Page<Son> result = new Page<Son>();
		result.setPage(page);
		result.setRows(sons);
		result.setSize(rows);
		result.setTotal(count);
		return result;
	}
	
	
	@Override
	public Integer addSon(Son son) {
		// TODO Auto-generated method stub
		return sonDao.addSon(son);
	}

	@Override
	public Integer addSon(List<Son> sons) {
		// TODO Auto-generated method stub
		int count=0;
		for(Son son :sons){
			System.out.println(son);
			count+=sonDao.addSon(son);
			
		}
		return count;
	}
	
	
	@Override
	public Integer deleteSon(String name) {
		// TODO Auto-generated method stub
		return sonDao.deleteSon(name);
	}
	
	
	//根据空巢老人姓名查询老人
	public Son findSonByName(String name){
		return sonDao.findSonByName(name);
	}
	
	//编辑空巢老人子女信息
	@Override
	public Integer findSonModify(Son son) {
		// TODO Auto-generated method stub
		
		return sonDao.findSonModify(son);
	}
	
	
	
	
}
