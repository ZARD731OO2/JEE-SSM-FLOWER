package com.edu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.edu.common.utils.Page;
import com.edu.po.Pro;
import com.edu.po.User;


public interface ProService {

	public Page<Pro> findProByCond2(Integer page, Integer rows, Pro pro);
	public Integer  addPro(Pro pro);
	public Integer addPro(List<Pro> pros);
	public Integer findProModify(Pro pro);
	public Integer deletePro(@Param("proname") String proname);
	public Pro findProByProname(String proname);

}
