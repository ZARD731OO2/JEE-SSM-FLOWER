package com.edu.service;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.edu.common.utils.Page;
import com.edu.po.Old;
import com.edu.po.Son;
public interface SonService {
	public Page<Son> findSonByCond2(Integer page, Integer rows, Son son);
	public Integer  addSon(Son son);
	public Integer addSon(List<Son> sons);
	public Integer deleteSon(@Param("name") String name);
	public Son findSonByName(String name);
	public Integer findSonModify(Son son);
}
