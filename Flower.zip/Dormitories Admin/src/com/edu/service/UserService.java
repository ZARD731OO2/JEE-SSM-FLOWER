package com.edu.service;

import java.util.List;
import com.edu.common.utils.Page;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;


import com.edu.po.User;

public interface UserService {
	public User findUserById(int id);
	public User findUserByIdAndPas(User user);
	public User register(User user);
	public Page<User> findUserByCond2(Integer page,Integer rows,User user);
	public Integer findUserModify(User user);
	public Integer deleteUser(@Param("id") Integer id);
	public List<User> findUserByIds(Integer[] ids);
	public Integer  addUser(User user);
	public int addUser(List<User> users);
}
