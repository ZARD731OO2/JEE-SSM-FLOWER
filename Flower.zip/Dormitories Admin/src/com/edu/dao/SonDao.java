package com.edu.dao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

import com.edu.common.utils.Page;
import com.edu.po.Old;
import com.edu.po.Son;

public interface SonDao {
	public List<Son> findSonByCond2(RowBounds rowBounds,Son son);
	public int findSonCountByCond2(Son son);
	public Integer addSon(Son son);
	public Integer addSon(List<Son> sons);
	public Integer deleteSon(@Param("name") String name);
	public Son findSonByName(String name);
	public Integer findSonModify(Son son);
}
