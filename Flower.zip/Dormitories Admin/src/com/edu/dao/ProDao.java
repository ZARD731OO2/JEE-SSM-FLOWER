package com.edu.dao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

import com.edu.common.utils.Page;
import com.edu.po.Pro;


public interface ProDao {
	public List<Pro> findProByCond2(RowBounds rowBounds,Pro pro);
	public int findProCountByCond2(Pro pro);
	public Integer addPro(Pro pro);
	public Integer addPro(List<Pro> pros);
	public Integer deletePro(@Param("proname") String proname);
	public Pro findProByProname(String proname);
	public Integer findProModify(Pro pro);
	
}
