package com.edu.dao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

import com.edu.common.utils.Page;
import com.edu.po.Pro;
import com.edu.po.Hua;

public interface HuaDao {
	public List<Hua> findHuaByCond2(RowBounds rowBounds,Hua pro);
	public int findHuaCountByCond2(Hua pro);
	public Integer addHua(Hua pro);
	public Integer addHua(List<Hua> pros);
	public Integer deleteHua(@Param("name") String name);
	public Hua findHuaByName(String name);
	public Integer findHuaModify(Hua pro);
}
