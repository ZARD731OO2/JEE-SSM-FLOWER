package com.edu.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

import com.edu.common.utils.Page;

import com.edu.po.User;

public interface UserDao {
	public User findUserByIdAndPas(User user);
	public User register(User user);
	public List<User> findUserByCond2(RowBounds rowBounds,User user);
	public int findUserCountByCond2(User user);
	public Integer findUserModify(User user);
	public User findUserById(int id);
	public Integer deleteUser(@Param("id") Integer id);
	public Integer addUser(User user);
	public int addUser(List<User> users);
}
