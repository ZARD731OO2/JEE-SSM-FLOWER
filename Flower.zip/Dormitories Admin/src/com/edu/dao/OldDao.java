package com.edu.dao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

import com.edu.common.utils.Page;
import com.edu.po.Old;


public interface OldDao {
	public List<Old> findOldByCond2(RowBounds rowBounds,Old old);
	public int findOldCountByCond2(Old old);
	public Integer addOld(Old old);
	public Integer addOld(List<Old> olds);
	public Integer deleteOld(@Param("oldname") String oldname);
	public Old findOldByOldname(String oldname);
	public Integer findOldModify(Old old);
	
}
