package com.edu.controller;
import java.io.File;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.edu.common.utils.Page;
import com.edu.db_util.DbToExcel;
import com.edu.po.Old;
import com.edu.po.User;
import com.edu.service.OldService;
@Controller
public class OldController {
	@Autowired
	private OldService oldService;
	
	@Autowired
	private DbToExcel dbToExcel;
	
	public DbToExcel getDbToExcel() {
		return dbToExcel;
	}
	public void setDbToExcel(DbToExcel dbToExcel) {
		this.dbToExcel = dbToExcel;
	}
	//显示空巢老人信息
	@RequestMapping("/toOld.action")
	public String toStudent(Model model,Old old,@RequestParam(defaultValue="1")Integer page,
			@RequestParam(defaultValue="3")Integer rows) {
		
		String forword="admin/old";
		Page<Old> olds=oldService.findOldByCond2(page,rows,old);
		model.addAttribute("page", olds);
		model.addAttribute("oldname", old.getOldname());
		
		return forword;
	}
	
	//新增空巢老人信息
	@RequestMapping("/toAddOld.action")
	public String toaddOld(Model model,HttpSession sesson) {
			
		
			//返回客户信息展示页面
			return "admin/addold";
		}
	
	@RequestMapping("/addold.action")
	public String addold( Old old) {
		
		//List<User> list = userService.findUserModify(user);
		oldService.addOld(old);
		return "admin/addusersuccess";
	}
	
	//删除空巢老人信息
	@RequestMapping("/deleteOld.action")
	public String deleteOld(String oldname,Model model) {
		System.out.println(oldname);
		oldService.deleteOld(oldname);
		System.out.println("1");
		return "redirect:toOld.action";
	}
	
	@RequestMapping("/toEditOld.action")
	public String toEditOld(String oldname,Model model,HttpSession sesson) {
		
		Old old =oldService.findOldByOldname(oldname);
		System.out.println(old);
		model.addAttribute("old", old);
		//返回客户信息展示页面
		return "admin/oldmodify";
	}
	
	

	
	@RequestMapping("/editold.action")
	public String editOld( Old old,Model model,HttpSession sesson) {
		
		//List<User> list = userService.findUserModify(user);
		oldService.findOldModify(old);
		return "admin/modifyusersuccess";
	}
  
	
}
