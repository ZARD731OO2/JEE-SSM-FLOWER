package com.edu.controller;
import java.io.File;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.edu.common.utils.Page;
import com.edu.db_util.DbToExcel;
import com.edu.po.Old;
import com.edu.po.Son;
import com.edu.service.SonService;
@Controller
public class SonController {
	@Autowired
	private SonService sonService;
	
	
	//显示子女信息
		@RequestMapping("/toSon.action")
		public String toSon(Model model,Son son,@RequestParam(defaultValue="1")Integer page,
				@RequestParam(defaultValue="3")Integer rows) {
			
			String forword="admin/son";
			Page<Son> sons=sonService.findSonByCond2(page,rows,son);
			model.addAttribute("page", sons);
			model.addAttribute("oldname", son.getName());
			
			return forword;
		}
	
		//新增空巢老人子女信息
		@RequestMapping("/toAddSon.action")
		public String toaddSon(Model model,HttpSession sesson) {
				
			
				//返回子女信息展示页面
				return "admin/addson";
			}
		
		@RequestMapping("/addson.action")
		public String addson( Son son) {
			
			
			sonService.addSon(son);
			return "admin/addusersuccess";
		}	
		
		//删除空巢老人子女信息
		@RequestMapping("/deleteSon.action")
		public String deleteOld(String name,Model model) {
			System.out.println(name);
			sonService.deleteSon(name);
			
			return "redirect:toSon.action";
		}
	
		
		@RequestMapping("/toEditSon.action")
		public String toEditSon(String name,Model model,HttpSession sesson) {
			
			Son son =sonService.findSonByName(name);
			System.out.println(son);
			model.addAttribute("son", son);
			//返回子女信息展示页面
			return "admin/sonmodify";
		}
		
		@RequestMapping("/editson.action")
		public String editSon( Son son,Model model,HttpSession sesson) {
			
		
			sonService.findSonModify(son);
			return "admin/modifyusersuccess";
		}
		
		
}
