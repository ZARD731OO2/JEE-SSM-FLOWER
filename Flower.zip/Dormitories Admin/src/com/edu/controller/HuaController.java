package com.edu.controller;
import java.io.File;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.edu.common.utils.Page;
import com.edu.db_util.DbToExcel;
import com.edu.po.Pro;
import com.edu.po.Hua;
import com.edu.service.HuaService;
@Controller
public class HuaController {
	@Autowired
	private HuaService huaService;
	
	
	//显示花卉信息
		@RequestMapping("/toHua.action")
		public String toHua(Model model,Hua hua,@RequestParam(defaultValue="1")Integer page,
				@RequestParam(defaultValue="3")Integer rows) {
			
			String forword="admin/hua";
			Page<Hua> huas=huaService.findHuaByCond2(page,rows,hua);
			model.addAttribute("page", huas);
			model.addAttribute("proname", hua.getName());
			
			return forword;
		}
	
		//新增花卉信息
		@RequestMapping("/toAddHua.action")
		public String toaddHua(Model model,HttpSession seshua) {
				
			
				//返回花卉信息展示页面
				return "admin/addhua";
			}
		
		@RequestMapping("/addhua.action")
		public String addhua( Hua hua) {
			
			
			huaService.addHua(hua);
			return "admin/addusersuccess";
		}	
		
		//删除花卉信息
		@RequestMapping("/deleteHua.action")
		public String deleteOld(String name,Model model) {
			System.out.println(name);
			huaService.deleteHua(name);
			
			return "redirect:toHua.action";
		}
	
		
		@RequestMapping("/toEditHua.action")
		public String toEditHua(String name,Model model,HttpSession seshua) {
			
			Hua hua =huaService.findHuaByName(name);
			System.out.println(hua);
			model.addAttribute("hua", hua);
			//返回花卉信息展示页面
			return "admin/huamodify";
		}
		
		@RequestMapping("/edithua.action")
		public String editHua( Hua hua,Model model,HttpSession seshua) {
			
		
			huaService.findHuaModify(hua);
			return "admin/modifyusersuccess";
		}
		
		
}
