package com.edu.controller;
import java.io.File;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.edu.common.utils.Page;
import com.edu.db_util.DbToExcel;
import com.edu.po.Pro;
import com.edu.po.User;
import com.edu.service.ProService;
@Controller
public class ProController {
	@Autowired
	private ProService proService;
	
	@Autowired
	private DbToExcel dbToExcel;
	
	public DbToExcel getDbToExcel() {
		return dbToExcel;
	}
	public void setDbToExcel(DbToExcel dbToExcel) {
		this.dbToExcel = dbToExcel;
	}
	//显示供应商信息
	@RequestMapping("/toPro.action")
	public String toStudent(Model model,Pro pro,@RequestParam(defaultValue="1")Integer page,
			@RequestParam(defaultValue="3")Integer rows) {
		
		String forword="admin/pro";
		Page<Pro> pros=proService.findProByCond2(page,rows,pro);
		model.addAttribute("page", pros);
		model.addAttribute("proname", pro.getProname());
		
		return forword;
	}
	
	//新增供应商信息
	@RequestMapping("/toAddPro.action")
	public String toaddPro(Model model,HttpSession sesson) {
			
		
			//返回客户信息展示页面
			return "admin/addpro";
		}
	
	@RequestMapping("/addpro.action")
	public String addpro( Pro pro) {
		
		//List<User> list = userService.findUserModify(user);
		proService.addPro(pro);
		return "admin/addusersuccess";
	}
	
	//删除供应商信息
	@RequestMapping("/deletePro.action")
	public String deletePro(String proname,Model model) {
		System.out.println(proname);
		proService.deletePro(proname);
		System.out.println("1");
		return "redirect:toPro.action";
	}
	
	@RequestMapping("/toEditPro.action")
	public String toEditPro(String proname,Model model,HttpSession sesson) {
		
		Pro pro =proService.findProByProname(proname);
		System.out.println(pro);
		model.addAttribute("pro", pro);
		//返回客户信息展示页面
		return "admin/promodify";
	}
	
	

	
	@RequestMapping("/editpro.action")
	public String editPro( Pro pro,Model model,HttpSession sesson) {
		
		//List<User> list = userService.findUserModify(user);
		proService.findProModify(pro);
		return "admin/modifyusersuccess";
	}
  
	
}
