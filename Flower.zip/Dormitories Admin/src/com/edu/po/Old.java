package com.edu.po;

public class Old {
	private String oldname;
	private String age;
	private String sex;
	private String phone;
	private String address;
	public String getOldname() {
		return oldname;
	}
	public void setOldname(String oldname) {
		this.oldname = oldname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Old [oldname=" + oldname + ", age=" + age + ", sex=" + sex + ", phone=" + phone + ", address=" + address
				+ "]";
	}
	
}
