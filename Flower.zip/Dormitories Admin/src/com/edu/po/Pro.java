package com.edu.po;

public class Pro {
	private String proname;
	private String id;
	private String ser;
	private String phone;
	private String address;
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSer() {
		return ser;
	}
	public void setSer(String ser) {
		this.ser = ser;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Pro [proname=" + proname + ", id=" + id + ", ser=" + ser + ", phone=" + phone + ", address=" + address
				+ "]";
	}
	
}
