package com.edu.po;

public class Son {
	private String name;
	private String oldname;
	private String sex;
	private String phone;
	private String workspace;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOldname() {
		return oldname;
	}
	public void setOldname(String oldname) {
		this.oldname = oldname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getWorkspace() {
		return workspace;
	}
	public void setWorkspace(String workspace) {
		this.workspace = workspace;
	}
	@Override
	public String toString() {
		return "Son [name=" + name + ", oldname=" + oldname + ", sex=" + sex + ", phone=" + phone + ", workspace="
				+ workspace + "]";
	}
	
}
