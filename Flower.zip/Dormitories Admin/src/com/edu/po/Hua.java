package com.edu.po;

public class Hua {
	private String name;
	private String proname;
	private String type;
	private String date;
	private String workspace;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getWorkspace() {
		return workspace;
	}
	public void setWorkspace(String workspace) {
		this.workspace = workspace;
	}
	@Override
	public String toString() {
		return "Hua [name=" + name + ", proname=" + proname + ", type=" + type + ", date=" + date + ", workspace="
				+ workspace + "]";
	}

}
